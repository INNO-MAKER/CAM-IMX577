# imx577 driver + overlay

> **Note on names.** This is the **imx577** product. The kernel module ships as
> `imx477.ko` (the imx477-family driver) and binds the sensor via a device-tree
> `compatible` string; there is no module literally named `imx577`. The overlay is
> `imx577.dtbo`. So on this system the working combination is
> **module `imx477.ko` + overlay `imx577.dtbo`** -- the filenames differ by design.

Exported from a running system. Kernel module and device-tree overlay only.

Kernel: **6.12.75+rpt-rpi-2712**    Variant: pi5
Built on: debian trixie (13)    Date: 20260720-140520

## Contents
- `driver/imx477.ko` -- vermagic `6.12.75+rpt-rpi-2712`
- `driver/imx577.dtbo`
- `install.sh`

## Install
```bash
sudo ./install.sh
sudo reboot
```

`install.sh` refuses to run on any kernel other than `6.12.75+rpt-rpi-2712`.
It does **not** modify `config.txt` -- manage the `dtoverlay=` line yourself.

Overlay params available: `always-on cam0 link-frequency media-controller orientation rotation sync-sink sync-source `

## Scope
Kernel side only. libcamera/IPA is packaged separately; nothing here depends on
the target's libcamera version.
