# libcamera Runtime Package -- imx577

Complete libcamera + rpicam-apps userspace stack, exported from a working system.
Supports: **imx577**

Build OS: debian trixie (13)
libcamera: **0.7.0** (SONAME `libcamera.so.0.7`)
Triplet: aarch64-linux-gnu    Variant: pi5    Date: 20260720-005005

## Install
```bash
sudo ./install.sh
```

Installs under `/usr/local`. The distro libcamera in `/usr/lib` is **not**
touched -- different SONAME, they coexist. No reboot needed for the runtime
(the driver package does need one).

## Why the whole stack ships together

`ipa_rpi_*.so` has `NEEDED: libcamera.so.0.7` and cannot load
against a different libcamera minor version -- libcamera bumps its SONAME every
release and makes no ABI-stability promise, so neither direction is compatible.
libcamera also signs IPA modules at build time with an ephemeral key, so an IPA
and a `libcamera.so` from two different builds fail signature validation even
at the same version. Shipping the IPA alone therefore cannot work.

Sensor support also spans both binaries: `cam_helper_<sensor>.cpp` is compiled
into the IPA, while the `camera_sensor_properties.cpp` entry lives in
`libcamera.so` itself.

## Compatibility

Independent of the target's libcamera version (we bring our own) and of the
kernel version (that's the driver package). The remaining external dependency is
**glibc / libstdc++**, which is backward compatible only: a package built on an
older OS runs on newer ones, but not the other way round. Built here on
debian 13; installing on anything older may fail with
`GLIBCXX_... not found`.

## Uninstall
```bash
sudo ./uninstall.sh
```
