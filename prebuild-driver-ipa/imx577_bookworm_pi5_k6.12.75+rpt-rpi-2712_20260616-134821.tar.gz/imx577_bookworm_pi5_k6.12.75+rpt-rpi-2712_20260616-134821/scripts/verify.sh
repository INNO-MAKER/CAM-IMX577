#!/bin/bash
# Auto-detect which IPA variant this host should have based on Pi model
if grep -q "Raspberry Pi 5" /proc/device-tree/model 2>/dev/null; then
    IPA_NAME="ipa_rpi_pisp.so"; T="/usr/share/libcamera/ipa/rpi/pisp/imx577.json"
else
    IPA_NAME="ipa_rpi_vc4.so";  T="/usr/share/libcamera/ipa/rpi/vc4/imx577.json"
fi
# IPA can live directly under libcamera/ (old) or libcamera/ipa/ (v0.5+)
IPA="$(find /usr/lib/aarch64-linux-gnu/libcamera -name "$IPA_NAME" 2>/dev/null | head -1)"
F=0
[ -n "$IPA" ] && [ -f "$IPA" ] && echo "[PASS] $IPA"           || { echo "[FAIL] $IPA_NAME not found"; F=1; }
strings "$IPA" 2>/dev/null | grep -qi imx577 \
                         && echo "[PASS] imx577 in $IPA_NAME"    || { echo "[WARN] imx577 not in $IPA_NAME (OK if using imx477 fallback)"; }
[ -e "$T" ]              && echo "[PASS] tuning $T"             || { echo "[FAIL] tuning $T"; F=1; }
modinfo imx477 2>/dev/null | grep -qi imx577 \
                         && echo "[PASS] kernel driver advertises imx577" \
                         || echo "[WARN] kernel driver does not list imx577 (did you reboot?)"
rpicam-hello --list-cameras 2>&1 | head -30 || true
exit $F
