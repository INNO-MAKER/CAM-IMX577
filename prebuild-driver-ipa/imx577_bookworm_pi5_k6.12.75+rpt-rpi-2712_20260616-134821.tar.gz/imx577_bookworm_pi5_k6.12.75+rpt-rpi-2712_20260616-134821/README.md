# IMX577 prebuilt bundle: imx577_bookworm_pi5_k6.12.75+rpt-rpi-2712_20260616-134821

This bundle was produced on:

- Model:    Raspberry Pi 5 Model B Rev 1.1
- OS:       debian bookworm (12)
- Kernel:   6.12.75+rpt-rpi-2712
- libcamera: libcamera.so.0.5 / libcamera-base.so.0.5
- IPA .so packaged: 1 (0 = target keeps its own generic IPA)

For best results, install on systems with the same kernel release and
libcamera soname. The installer does not enforce this — if the kernel
module's vermagic doesn't match, modprobe will refuse to load imx477 at
boot (check `dmesg | grep imx477` after reboot).

## Install

    tar -xzf imx577_bookworm_pi5_k6.12.75+rpt-rpi-2712_20260616-134821.tar.gz
    cd imx577_bookworm_pi5_k6.12.75+rpt-rpi-2712_20260616-134821
    sudo ./scripts/install.sh
    sudo reboot
    ./scripts/verify.sh
