# IMX577 prebuilt bundle: imx577_trixie_pi5_k6.12.75+rpt-rpi-2712_20260418-201631

This bundle was produced on:

- Model:    Raspberry Pi 5 Model B Rev 1.0
- OS:       debian trixie (13)
- Kernel:   6.12.75+rpt-rpi-2712
- libcamera: libcamera.so.0.6 / libcamera-base.so.0.6

For best results, install on systems with the same kernel release and
libcamera soname. The installer does not enforce this — if the kernel
module's vermagic doesn't match, modprobe will refuse to load imx477 at
boot (check `dmesg | grep imx477` after reboot).

## Install

    tar -xzf imx577_trixie_pi5_k6.12.75+rpt-rpi-2712_20260418-201631.tar.gz
    cd imx577_trixie_pi5_k6.12.75+rpt-rpi-2712_20260418-201631
    sudo ./scripts/install.sh
    sudo reboot
    ./scripts/verify.sh
