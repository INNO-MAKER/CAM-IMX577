#!/bin/bash
# imx577 bundle installer — copies binaries into place. No compatibility checks.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
TS="$(date +%Y%m%d-%H%M%S)"
HOST_REL="$(uname -r)"
LC_DIR="/usr/lib/aarch64-linux-gnu"

# Auto-detect which IPA .so is in this bundle (pi5=pisp, pi4=vc4)
IPA_PATH="$(ls "$ROOT"/libcamera/ipa_rpi_*.so 2>/dev/null | head -1)"
[ -n "$IPA_PATH" ] || { echo "ERROR: no ipa_rpi_*.so found in $ROOT/libcamera/"; exit 1; }
IPA_NAME="$(basename "$IPA_PATH")"
case "$IPA_NAME" in
    ipa_rpi_pisp.so) TUNE_DIR="/usr/share/libcamera/ipa/rpi/pisp" ;;
    ipa_rpi_vc4.so)  TUNE_DIR="/usr/share/libcamera/ipa/rpi/vc4" ;;
    *)               echo "ERROR: unexpected IPA name $IPA_NAME"; exit 1 ;;
esac

echo "Installing ($IPA_NAME, kernel $HOST_REL)..."

# ─── 1. kernel driver ────────────────────────────────────────────────────────
DEST="/lib/modules/$HOST_REL/kernel/drivers/media/i2c"
mkdir -p "$DEST"
[ -f "$DEST/imx477.ko.xz" ] && mv "$DEST/imx477.ko.xz" "$DEST/imx477.ko.xz.bak.$TS" \
    && echo "  backed up compressed stock imx477.ko.xz"
[ -f "$DEST/imx477.ko" ] && cp "$DEST/imx477.ko" "$DEST/imx477.ko.bak.$TS"
cp "$ROOT/driver/imx477.ko" "$DEST/"
depmod -a
echo "  driver installed"

# ─── 2. device tree overlay ──────────────────────────────────────────────────
cp "$ROOT/dts/imx577-overlay.dtbo" /boot/firmware/overlays/
echo "  dtbo installed"

# ─── 3. libcamera IPA ────────────────────────────────────────────────────────
mkdir -p "$LC_DIR/libcamera"
[ -f "$LC_DIR/libcamera/$IPA_NAME" ] \
    && cp "$LC_DIR/libcamera/$IPA_NAME" "$LC_DIR/libcamera/${IPA_NAME}.bak.$TS"
cp "$ROOT/libcamera/$IPA_NAME" "$LC_DIR/libcamera/"
[ -f "$ROOT/libcamera/${IPA_NAME}.sign" ] \
    && cp "$ROOT/libcamera/${IPA_NAME}.sign" "$LC_DIR/libcamera/"
ldconfig
echo "  IPA installed"

# ─── 4. tuning file ──────────────────────────────────────────────────────────
mkdir -p "$TUNE_DIR"
if [ -f "$ROOT/tuning/imx577.json" ]; then
    cp "$ROOT/tuning/imx577.json" "$TUNE_DIR/"
    echo "  tuning file installed (real)"
elif [ -f "$TUNE_DIR/imx477.json" ]; then
    [ -e "$TUNE_DIR/imx577.json" ] && rm -f "$TUNE_DIR/imx577.json"
    ln -sf imx477.json "$TUNE_DIR/imx577.json"
    echo "  tuning file: imx577.json -> imx477.json (symlink)"
fi

# ─── 5. config.txt ───────────────────────────────────────────────────────────
CFG=/boot/firmware/config.txt
cp "$CFG" "$CFG.bak.$TS"
sed -i '/^dtoverlay=imx577/d;/^dtoverlay=imx477/d;/^camera_auto_detect/d' "$CFG"
{
    echo ""
    echo "# IMX577 + IMX477 (from bundle, installed $TS)"
    echo "camera_auto_detect=0"
    echo "dtoverlay=imx577-overlay,cam0"
    echo "dtoverlay=imx477,cam1"
} >> "$CFG"
echo "  config.txt updated"

echo ""
echo "All done. Reboot required:  sudo reboot"
echo "After reboot:                rpicam-hello --list-cameras"
